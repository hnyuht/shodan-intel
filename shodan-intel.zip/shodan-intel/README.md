# ShodanIntel — Threat Intelligence Dashboard

Matrix-themed cybersecurity dashboard powered by **Shodan API** + **Claude AI**.

```
shodan-intel/
├── index.html      ← Full dashboard + AI Analyst (single file app)
├── config.js       ← DROP YOUR API KEYS HERE
├── start.sh        ← Start script (Mac / Linux)
├── start.bat       ← Start script (Windows)
└── README.md
```

## Setup

### 1. Add your API keys

Open **`config.js`** and replace the placeholders:

```js
const CONFIG = {
  SHODAN_API_KEY:    "your-shodan-key-here",
  ANTHROPIC_API_KEY: "your-anthropic-key-here",
};
```

| Key | Get it at |
|-----|-----------|
| Shodan | https://account.shodan.io → My Account |
| Anthropic | https://console.anthropic.com → API Keys |

### 2. Start the app

**Mac / Linux:**
```bash
chmod +x start.sh
./start.sh
```

**Windows:** Double-click `start.bat`

The browser opens automatically at `http://localhost:8080`.

---

## Features

### Overview Tab
- Live metric cards (critical/high exposure, RDP/SSH/DB counts)
- Worker telemetry grid showing active scan jobs
- Risk distribution donut chart
- 14-day exposure timeline
- Results table with IP, org, risk rating

### AI Analyst Tab
- Natural language threat queries powered by Claude
- Agentic loop — Claude calls Shodan multiple times per question
- Example queries:
  - *"Which hosts have the most risk exposure?"*
  - *"Show orgs with RDP port 3389 open"*
  - *"Is [company] exposed? Search org:CompanyName"*
  - *"Find unprotected MongoDB instances in the US"*

---

## Risk Tiers

| Level | Ports |
|-------|-------|
| 🔴 CRITICAL | 23, 445, 3389, 5900, 4444, 2375 |
| 🟠 HIGH | 22, 3306, 5432, 27017, 6379, 9200, 1433 |
| 🟡 MEDIUM | 8080, 8443, 21, 25, 8888 |
| 🟢 LOW | 80, 443, 53, 123 |

---

> ⚠️ For personal/local use only. Do not expose `config.js` publicly — it contains your API keys. Only query networks you are authorized to assess.
